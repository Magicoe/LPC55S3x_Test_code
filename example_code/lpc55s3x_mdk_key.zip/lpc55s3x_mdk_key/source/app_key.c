/*
 * Copyright (c) 2017 - 2020 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#include "fsl_common.h"
#include "fsl_iocon.h"
#include "fsl_gpio.h"
#include "app_key.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
 
uint8_t read_btn0_status(void)
{
    if(GPIO_PinRead(GPIO, KEY_S2_PORT, KEY_S2_PIN) == 0)  /* ��ȡGPIO״̬ */
    {
        return 1;
    }
    return 0;
}

uint8_t read_btn1_status(void)
{
    if(GPIO_PinRead(GPIO, KEY_S3_PORT, KEY_S3_PIN) == 0)  /* ��ȡGPIO״̬ */
    {
        return 1;
    }
    return 0;
}

/**
 * @brief   ����IO��״̬��ȡ
 * @param   NULL
 * @return  ���ذ��°�������ֵ
 */
uint8_t key_read(void)
{
    uint8_t value = 0;

    if(GPIO_PinRead(GPIO, KEY_S2_PORT, KEY_S2_PIN) == 0)  /* ��ȡGPIO״̬ */
    {
        value |= KEY2_NUM;
        return value;
    }
    if(GPIO_PinRead(GPIO, KEY_S3_PORT, KEY_S3_PIN) == 0)  /* ��ȡGPIO״̬ */
    {
        value |= KEY3_NUM;
        return value;
    }
    return 0;
}

/**
 * @brief   ����GPIO�ڳ�ʼ��
 * @param   NULL
 * @return  NULL
 */
void key_init(void)
{
    static uint32_t i = 0;
    gpio_pin_config_t   gpioPinConfig;
    
    gpioPinConfig.pinDirection = kGPIO_DigitalInput;       /* ����GPIO��Ϊ���� */
    gpioPinConfig.outputLogic  = 1u;
    
    /* ʹ��IO��������ʱ�� */
    CLOCK_EnableClock(kCLOCK_Iocon);
    IOCON->PIO[KEY_S2_PORT][KEY_S2_PIN] = KEY_S2_FUNC;     /* KEY S2 �ܽ����� */
    IOCON->PIO[KEY_S3_PORT][KEY_S3_PIN] = KEY_S3_FUNC;     /* KEY S3 �ܽ����� */
    /* ����IO��������ʹ��, ��Լ���� */
    CLOCK_DisableClock(kCLOCK_Iocon);
    
    /* GPIO ���ų�ʼ�� */
    GPIO_PinInit (GPIO, KEY_S2_PORT, KEY_S2_PIN, &gpioPinConfig);
    GPIO_PinInit (GPIO, KEY_S3_PORT, KEY_S3_PIN, &gpioPinConfig);
}

// end file

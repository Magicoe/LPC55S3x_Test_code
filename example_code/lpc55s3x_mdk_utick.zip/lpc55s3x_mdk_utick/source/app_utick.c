/*
 * Copyright (c) 2017 - 2021 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_utick.h"


/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint8_t g_UtickExpired = 0;

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Main function
 */
void UTickCallback(void)
{
    g_UtickExpired = 1;
}

 
/**
 * @brief   
 * @param   NULL
 * @return  NULL
 */
void utick_init(void)
{
    // Enable FRO 1MHz clock for UTICK.
    SYSCON->CLOCK_CTRL |= SYSCON_CLOCK_CTRL_FRO1MHZ_UTICK_ENA_MASK;
    /* Intiialize UTICK */
    UTICK_Init(UTICK0);
    g_UtickExpired = 0;
}

/**
 * @brief   
 * @param   
 * @param   
 * @return  NULL
 */
void utick_set(uint32_t value)
{
    /* Set the UTICK timer to wake up the device from reduced power mode */
    UTICK_SetTick(UTICK0, kUTICK_Onetime, value - 1, UTickCallback);
    g_UtickExpired = 0;
}

// end file

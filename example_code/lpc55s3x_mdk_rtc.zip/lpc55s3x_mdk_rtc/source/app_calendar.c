/*
 * Copyright (c) 2017 - 2018 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "app_calendar.h"
#include "fsl_irtc.h"
#include "fsl_power.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint8_t g_AlarmFlag = 0;

/*******************************************************************************
 * Code
 ******************************************************************************/

/*!
 * @brief ISR for Alarm interrupt
 *
 * This function change state of busyWait.
 */
void RTC_IRQHandler(void)
{
    if (IRTC_GetStatusFlags(RTC) & kIRTC_AlarmFlag)
    {
        g_AlarmFlag = 1;
        /* Unlock to allow register write operation */
        IRTC_SetWriteProtection(RTC, false);
        /*Clear alarm flag */
        IRTC_ClearStatusFlags(RTC, kIRTC_AlarmInterruptEnable);
    }
    SDK_ISR_EXIT_BARRIER;
}



/**
 * @brief   Init RTC
 * @param   NULL
 * @return  NULL
 */
uint8_t calendar_init(void)
{
    irtc_datetime_t date;
    irtc_config_t irtcConfig;
    
    /* Init RTC */
    /* Enable the RTC peripheral clock */
    POWER_DisablePD(kPDRUNCFG_PD_XTAL32K);
    CLOCK_AttachClk(kXTAL32K_to_OSC32K);
    
    date.year    = 2015;
    date.month   = 1;
    date.day     = 21;
    date.weekDay = 3;
    date.hour    = 18;
    date.minute  = 55;
    date.second  = 30;
    
    IRTC_GetDefaultConfig(&irtcConfig);
    if (IRTC_Init(RTC, &irtcConfig) == kStatus_Fail)
    {
        return 1;
    }
    /* Enable the RTC 32KHz oscillator at CFG0 by writing a 0 */
    IRTC_Enable32kClkDuringRegisterWrite(RTC, true);
    /* Clear all Tamper events by writing a 1 to the bits */
    IRTC_ClearTamperStatusFlag(RTC);
    IRTC_SetDatetime(RTC, &date);
    
    
    return 0;
}

/**
 * @brief   Set RTC value
 * @param   date - 
 * @return  NULL
 */
void calendar_set(rtc_datetime_t date)
{

    
}

/**
 * @brief   Set RTC alarm value
 * @param   date - 
 * @return  NULL
 */
void calendar_alarmset(rtc_datetime_t *alarmdate)
{
    irtc_datetime_t date;
    
    date.year    = alarmdate->year;
    date.month   = alarmdate->month;
    date.day     = alarmdate->day;
    date.weekDay = alarmdate->weekDay;
    date.hour    = alarmdate->hour;
    date.second  = alarmdate->second;
    date.minute  = alarmdate->minute;
    
    IRTC_SetAlarm(RTC, &date);
    /* Enable RTC alarm interrupt */
    IRTC_EnableInterrupts(RTC, kIRTC_AlarmInterruptEnable);
    /* Enable at the NVIC */
    EnableIRQ(RTC_IRQn);
}

/**
 * @brief   Read RTC value
 * @param   NULL
 * @return  date
 */
void calendar_read(rtc_datetime_t* data)
{
    irtc_datetime_t datetime;
    IRTC_GetDatetime(RTC, &datetime); /* Get date time */
    data->year    = datetime.year;
    data->month   = datetime.month;
    data->day     = datetime.day;
    data->hour    = datetime.hour;
    data->second  = datetime.second;
    data->minute  = datetime.minute;
    data->weekDay = datetime.weekDay;
}


/**
 * @brief   RTC Task
 * @param   NULL
 * @return  NULL
 */
void calendar_task(void)
{
    rtc_datetime_t date;
    calendar_read(&date);           /* Read RTC Value */
}

// end file
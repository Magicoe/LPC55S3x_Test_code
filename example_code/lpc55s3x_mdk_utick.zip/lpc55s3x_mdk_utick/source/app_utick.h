/*
 * Copyright (c) 2017 - 2021 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __APP_UTICK_H__
#define __APP_UTICK_H__

#include <stdint.h>


/*******************************************************************************
 * Definitions
 ******************************************************************************/

extern volatile uint8_t g_UtickExpired;

extern void utick_init(void);
extern void utick_set(uint32_t value);

#endif

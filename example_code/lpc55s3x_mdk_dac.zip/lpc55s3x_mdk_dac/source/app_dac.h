/*
 * Copyright (c) 2017 - 2021 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __APP_DAC_H__
#define __APP_DAC_H__

#include <stdint.h>

#include "fsl_common.h"
#include "fsl_dac.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

#define APP_DAC0_VREF     kDAC_ReferenceVoltageSourceAlt1


extern void dac_init(uint8_t index, dac_reference_voltage_source_t vref);
extern void dac_set(uint8_t index, uint32_t value);

#endif

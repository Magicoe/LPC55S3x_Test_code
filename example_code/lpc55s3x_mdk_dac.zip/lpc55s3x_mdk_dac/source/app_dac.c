/*
 * Copyright (c) 2017 - 2021 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "app_dac.h"
#include "fsl_power.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
/**
 * @brief   Initialize DAC
 * @param   NULL
 * @return  NULL
 */
void dac_init(uint8_t index, dac_reference_voltage_source_t vref)
{
    dac_config_t dacConfigStruct;
    
    if(index == 0)
    {
        CLOCK_SetClkDiv(kCLOCK_DivDac0Clk, 1U, true);
        CLOCK_AttachClk(kMAIN_CLK_to_DAC0);
        /* Enable DAC0 power -- Disable DAC0 power down */
        POWER_DisablePD(kPDRUNCFG_PD_DAC0);

        /* Configure the DAC. */
        DAC_GetDefaultConfig(&dacConfigStruct);
        dacConfigStruct.referenceVoltageSource = vref;
        DAC_Init(DAC0, &dacConfigStruct);
        DAC_Enable(DAC0, true); /* Enable the logic and output. */
    }
    if(index == 1)
    {
        CLOCK_SetClkDiv(kCLOCK_DivDac1Clk, 1U, true);
        CLOCK_AttachClk(kMAIN_CLK_to_DAC1);
        /* Enable DAC0 power -- Disable DAC1 power down */
        POWER_DisablePD(kPDRUNCFG_PD_DAC1);

        /* Configure the DAC. */
        DAC_GetDefaultConfig(&dacConfigStruct);
        dacConfigStruct.referenceVoltageSource = vref;
        DAC_Init(DAC1, &dacConfigStruct);
        DAC_Enable(DAC1, true); /* Enable the logic and output. */
    }
    if(index == 2)
    {
        CLOCK_SetClkDiv(kCLOCK_DivDac2Clk, 1U, true);
        CLOCK_AttachClk(kMAIN_CLK_to_DAC2);
        /* Enable DAC0 power -- Disable DAC2 power down */
        POWER_DisablePD(kPDRUNCFG_PD_DAC2);

        /* Configure the DAC. */
        DAC_GetDefaultConfig(&dacConfigStruct);
        dacConfigStruct.referenceVoltageSource = vref;
        DAC_Init(DAC2, &dacConfigStruct);
        DAC_Enable(DAC2, true); /* Enable the logic and output. */
    }
}

/**
 * @brief   
 * @param   
 * @param   
 * @return  NULL
 */
void dac_set(uint8_t index, uint32_t value)
{
    if(index == 0)  DAC_SetData(DAC0, value);
    if(index == 1)  DAC_SetData(DAC1, value);
    if(index == 2)  DAC_SetData(DAC2, value);
}


// end file

/*
 * Copyright (c) 2017 - 2021 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "clock_config.h"
#include "app_led.h"
#include "app_printf.h"
#include "app_calendar.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
rtc_datetime_t g_RTCdate;
rtc_datetime_t g_Alarmdate;

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Main function
 */
int main(void)
{
    /* Init board hardware. */
    BOARD_BootClockFRO12M();
    led_init();
    debug_init(115200);
    PRINTF("Hello LPC55S3x\r\n");
    
    calendar_init();
    
    g_AlarmFlag = 0;
    calendar_read(&g_Alarmdate);
    g_Alarmdate.minute = g_Alarmdate.minute + 1; // 1 minutes
    calendar_alarmset(&g_Alarmdate);
    while (1)
    {
        if(g_AlarmFlag == 1)
        {
            PRINTF("Alarm Ring Ring!!\r\n");
            g_AlarmFlag = 0;
        }
        led_toggle(LEDR_NUM);
        calendar_read(&g_RTCdate);
        PRINTF("Y %d M %d D %d H%d:M%d:S%d\r\n", g_RTCdate.year, g_RTCdate.month, g_RTCdate.day, g_RTCdate.hour, g_RTCdate.minute, g_RTCdate.second );
        SDK_DelayAtLeastUs(100000U, SDK_DEVICE_MAXIMUM_CPU_CLOCK_FREQUENCY);
    }
}

// end file

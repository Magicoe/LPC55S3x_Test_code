/*
 * Copyright (c) 2017 - 2020 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __APP_KEY_H__
#define __APP_KEY_H__

#include <stdint.h>

#include "fsl_common.h"
#include "fsl_iocon.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define KEY_S2_PORT    0u
#define KEY_S2_PIN     5u
#define KEY_S2_FUNC    (IOCON_FUNC0 | IOCON_MODE_PULLUP | IOCON_DIGITAL_EN)

#define KEY_S3_PORT    0u
#define KEY_S3_PIN     7u
#define KEY_S3_FUNC    (IOCON_FUNC0 | IOCON_MODE_PULLUP | IOCON_DIGITAL_EN)

#define KEY2_NUM       0x01
#define KEY3_NUM       0x02

extern void    key_init(void);
extern uint8_t key_read(void);
uint8_t key_task(void);

#endif

// end file

/*
 * Copyright (c) 2017 - 2021 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "clock_config.h"
#include "app_led.h"
#include "app_printf.h"

#include "app_utick.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Main function
 */
int main(void)
{
    /* Init board hardware. */
    BOARD_BootClockFRO12M();
    led_init();
    debug_init(115200);
    PRINTF("Hello LPC55S3x\r\n");
    
    utick_init();

    while (1)
    {
        led_toggle(LEDR_NUM);
        utick_set(1000000); // 1MHz * 1000000 = 1S
        while(g_UtickExpired == 0);
    }
}

// end file

/*
 * Copyright (c) 2017 - 2018 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __APP_CALENDAR_H__
#define __APP_CALENDAR_H__

#include "stdint.h"
#include "fsl_irtc.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/*! @brief Structure is used to hold the date and time */
typedef struct _rtc_datetime
{
    uint16_t year;  /*!< Range from 1970 to 2099.*/
    uint8_t month;  /*!< Range from 1 to 12.*/
    uint8_t day;    /*!< Range from 1 to 31 (depending on month).*/
    uint8_t hour;   /*!< Range from 0 to 23.*/
    uint8_t minute; /*!< Range from 0 to 59.*/
    uint8_t second; /*!< Range from 0 to 59.*/
    uint8_t weekDay;
} rtc_datetime_t;



#define RTCTASKDEBUG  0x01                 /* Debug RTC task function */

extern volatile uint8_t g_AlarmFlag;


extern uint8_t        calendar_init(void);
extern void           calendar_set (rtc_datetime_t data);
extern void           calendar_alarmset (rtc_datetime_t *alarmdata);
extern void           calendar_read(rtc_datetime_t* data);
extern void           calendar_task(void);


#endif /* __APP_CALENDAR_H__ */

// end file
/*
 * Copyright (c) 2017 - 2021 , NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "clock_config.h"
#include "app_led.h"
#include "app_printf.h"

#include "app_dac.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
/*!
 * @brief Main function
 */
int main(void)
{
    uint32_t i;
    /* Init board hardware. */
    BOARD_BootClockFRO12M();
    led_init();
    debug_init(115200);
    PRINTF("Hello LPC55S3x, This is DAC demo\r\n");
    
    dac_init(0, kDAC_ReferenceVoltageSourceAlt1);
    i = 0;
    while (1)
    {
        if(i <= 0xFFFU) dac_set(0, i);
        else i = 0;
        i++;
        led_toggle(LEDR_NUM);
        SDK_DelayAtLeastUs(10000U, SDK_DEVICE_MAXIMUM_CPU_CLOCK_FREQUENCY);
    }
}

// end file
